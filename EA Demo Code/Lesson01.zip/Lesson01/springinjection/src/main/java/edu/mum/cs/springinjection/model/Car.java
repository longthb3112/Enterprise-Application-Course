package edu.mum.cs.springinjection.model;

public interface Car {
}
