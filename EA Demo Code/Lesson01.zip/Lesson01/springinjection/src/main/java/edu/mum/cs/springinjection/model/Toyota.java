package edu.mum.cs.springinjection.model;

import org.springframework.stereotype.Component;

@Component
public class Toyota implements Car{}
