package edu.mum.cs.springinjection.model;

import org.springframework.stereotype.Component;

@Component
public class Volkswagen implements Car{}