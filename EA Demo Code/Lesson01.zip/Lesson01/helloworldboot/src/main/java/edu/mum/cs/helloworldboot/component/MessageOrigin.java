package edu.mum.cs.helloworldboot.component;

public interface MessageOrigin {
   public String getMessage();
}
