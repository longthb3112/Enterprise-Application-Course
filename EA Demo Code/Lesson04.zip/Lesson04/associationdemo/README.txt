Need to comment/uncomment @Entity to demo for each case
