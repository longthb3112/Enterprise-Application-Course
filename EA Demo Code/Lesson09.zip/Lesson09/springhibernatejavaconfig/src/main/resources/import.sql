INSERT INTO Customer VALUES(NULL, 'James Reagon');
INSERT INTO Customer VALUES(NULL, 'Lilly Johnson');
INSERT INTO Customer VALUES(NULL, 'George Tall');