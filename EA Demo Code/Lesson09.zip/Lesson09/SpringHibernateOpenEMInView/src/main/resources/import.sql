INSERT INTO Address VALUES(NULL, 'New York');
INSERT INTO Address VALUES(NULL, 'Los Angeles');
INSERT INTO Address VALUES(NULL, 'Chicago');

INSERT INTO Customer VALUES(NULL, 'James Reagon', 1);
INSERT INTO Customer VALUES(NULL, 'Lilly Johnson', 2);
INSERT INTO Customer VALUES(NULL, 'George Tall', 3);

