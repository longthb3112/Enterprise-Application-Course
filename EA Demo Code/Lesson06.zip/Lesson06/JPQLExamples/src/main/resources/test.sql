insert into Address value(null, 'Fairfield', 'Iowa', '1000 N 4th', '52557');
INSERT into Person values(null, 'John', 'Doe', 1);
INSERT into Person values(null, 'James', 'Brown', 1);
INSERT into Person values(null, 'Alice', 'Long', 1);
-- INSERT into Person values(null, 'John2', 'Doe2', 1);
-- INSERT into Person values(null, 'James2', 'Brown2', 1);
-- INSERT into Person values(null, 'Alice2', 'Long2', 1);
-- INSERT into Person values(null, 'John3', 'Doe3', 1);
-- INSERT into Person values(null, 'James3', 'Brown3', 1);
-- INSERT into Person values(null, 'Alice3', 'Long3', 1);
-- INSERT into Person values(null, 'John4', 'Doe4', 1);
-- INSERT into Person values(null, 'James4', 'Brown4', 1);
-- INSERT into Person values(null, 'Alice4', 'Long4', 1);
-- INSERT into Person values(null, 'John5', 'Doe5', 1);
-- INSERT into Person values(null, 'James5', 'Brown5', 1);
-- INSERT into Person values(null, 'Alice5', 'Long5', 1);
-- INSERT into Person values(null, 'John6', 'Doe6', 1);
-- INSERT into Person values(null, 'James6', 'Brown6', 1);
-- INSERT into Person values(null, 'Alice6', 'Long6', 1);


-- create procedure calculate(IN x int, IN y int, OUT sum int, OUT prod int) begin select x + y into sum; 	select x * y into prod; end;

